<?php
class Woowup_Checkouthook_Model_Observer {
	/*Notifica a WoowUp una vez que el usuario realizo el checkout de la cartilla*/
	public function dispatch(Varien_Event_Observer $observer) {
		$order = $observer->getEvent()->getOrder();

		Mage::getModel('woowup_checkouthook/hook')
			->execute($order);

		return true;

	}

}
?>