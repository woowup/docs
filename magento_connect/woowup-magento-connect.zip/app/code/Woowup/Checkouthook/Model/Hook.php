<?php
/**
* Primary Checkout Hook for magento post checkout
*/
class WoowUp_Checkouthook_Model_Hook
{
    private $_apiKey;
    private $_contestId;
    private $_apiUrl = 'www.woowup.com/apiv2/';

    /*Entrance point*/
    public function execute($order){

        $this->_contestId = Mage::getStoreConfig('woowup/general/contest_id',Mage::app()->getStore());
        $this->_apiKey = Mage::getStoreConfig('woowup/general/api_key',Mage::app()->getStore());

        $uId = $this->getWoowupUIdByMail($order->getCustomerEmail());


        if (!empty($uId)){
            $salePoints = $this->getContestSalePoints();
            $points = ceil($salePoints * floor($order->getGrandTotal()));
            $orderDetail = $this->createOrderDetailJson($order);

            $this->commitPointsToWoowup($uId, $points, $order->getId(), $orderDetail);
        }else{
            //No se encuentra el usuario
            Mage::log(
               "{user id not found with email: ".$order->getCustomerEmail()."}",
               null,
               'woowup-connect.log',
               true
            );
        }

    }

    /*Calls the api to get the user id to be used in add_sale_points_by_uid*/
    private function getWoowupUIdByMail($email) {

        if ($curl = curl_init()) {
            $headers = array();
            $headers[] = 'Content-Type: application/json';
            $headers[] = 'ApiKey: ' . $this->_apiKey;
            $headers[] = 'username:'. $this->_contestId;
            $headers[] = 'Content-Type: application/json';
            $headers[] = 'Accept: application/json';

            $url = $this->_apiUrl.$this->_contestId."/user_by_email/?email=".$email;

            curl_setopt($curl, CURLOPT_URL, $url);
            curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($curl, CURLOPT_HEADER, false);
            curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);

            try {
                $response = curl_exec($curl);
                $result   = $this->parseResult($response, $curl);
            } catch (Exception $e) {
                Mage::logException($e);
            }

            curl_close($curl);

            if ($result["status"]){
                return $result["data"]["user"]["service_uid"];
            }

            return false;
        }
        return false;
    }

    /*Returns an assotiative array based on the json response*/
    private function parseResult($response, $curl){
        if (!empty($response)){
            return json_decode($response, true);
        } else {
            return false;
        }
    }

    /*Makes the request post to woowup to add points to the magento user*/
    private function commitPointsToWoowup($uId, $points, $orderNumber, $orderDetail) {
        if ($curl = curl_init()) {
            $headers = array();
            $headers[] = 'ApiKey: ' . $this->_apiKey;
            $headers[] = 'username:'. $this->_contestId;
            $headers[] = 'Content-Type: application/x-www-form-urlencoded';
            $headers[] = 'Accept: application/json';

            $url = $this->_apiUrl.$this->_contestId."/add_sale_points_by_uid";

            $parameters["app_id"] = $this->_contestId;
            $parameters["uid"] = $uId;
            $parameters["points"] = $points;
            $parameters["nrofactura"] = $orderNumber;
            $parameters["factura"] = $orderDetail;

            curl_setopt($curl, CURLOPT_URL, $url);
            curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($curl, CURLOPT_HEADER, false);
            curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
            curl_setopt($curl, CURLOPT_POST, true);
            curl_setopt($curl, CURLOPT_POSTFIELDS, http_build_query($parameters));

            try {
                $response = curl_exec($curl);
                $result   = $this->parseResult($response, $curl);
            } catch (Exception $e) {
                Mage::logException($e);
            }
            curl_close($curl);

            // Mage::log(
            //    "{commit points to woowup: ".$response."}",
            //    null,
            //    'woowup-connect.log',
            //    true
            // );

            if ($result["status"])
                return true;

            return false;
        }
        return false;
    }

    /*Contest Points per sale*/
    private function getContestSalePoints() {

        if ($curl = curl_init()) {
            $headers = array();
            $headers[] = 'ApiKey: ' . $this->_apiKey;
            $headers[] = 'username:'. $this->_contestId;
            $headers[] = 'Content-Type: application/json';
            $headers[] = 'Accept: application/json';

            $url = $this->_apiUrl.$this->_contestId."/contest_sale_points/";

            curl_setopt($curl, CURLOPT_URL, $url);
            curl_setopt($curl, CURLOPT_RETURNTRANSFER, $headers);
            curl_setopt($curl, CURLOPT_HEADER, false);
            curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);

            try {
                $response = curl_exec($curl);
                $result   = $this->parseResult($response, $curl);
            } catch (Exception $e) {
                Mage::logException($e);
            }

            curl_close($curl);
            if ($result["status"])
                return (double)$result["data"]["contest_sale_points"];

            return false;
        }
        return false;
    }

    private function createOrderDetailJson($order) {
        $orderDetail = array();

        foreach ($order->getAllVisibleItems() as $item) {
            $orderDetail[] = array(
                    'codigo' => $item->getSku(),
                    'producto' => $item->getName(),
                    'cantidad' => $item->getQtyOrdered(),
                    'precio' => $item->getPrice()
                );
        }

        return json_encode($orderDetail);
    }
}
?>
